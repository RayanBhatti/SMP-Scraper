import './globals.css'
export const metadata = { title: 'ASX Scraper', description: 'Serverless demo' };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body style={{
        margin: 0,
        fontFamily: 'Inter, ui-sans-serif, system-ui',
        background: '#0b1020',
        color: '#e6edf3'
      }}>
        {children}
      </body>
    </html>
  );
}
